package biblio;

import java.math.BigInteger;
import java.util.List;
 import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class userLibro {
     private BigInteger presta;     
     private String cedula, nombre, devuelve;
    


       
    public String getCedula() {
        return cedula;
    }
  
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }
       
    public BigInteger  getPresta() {
        return presta;
    }
 
      public void setPresta(BigInteger presta) {
        this.presta = presta;
    }
       
    public String  getDevuelve() {
        return devuelve;
    }
 
  
    public void setDevuelve(String devuelve) {
        this.devuelve = devuelve;
    }
    
     public String getNomnre() {
        return nombre;
    }
  
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}